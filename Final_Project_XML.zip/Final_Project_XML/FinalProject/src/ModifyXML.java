import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;

/**
 * La classe permet de modifier l'élément présent dans une balise d'un fichier XML.
 *
 */
public class ModifyXML {
	/**
	 * La méthode prend en argument deux chaînes de caractère
	 * @param filePath chemin du fichier XML
	 * @param settitle par quoi on souhaite modifier la balise du fichier XML
	 */
	public static void modifyTitle(String fichierXML, String settitle) {
	     try {
				File inputFile = new File(fichierXML);
				DocumentBuilderFactory Factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder constructeur = Factory.newDocumentBuilder();
				
				//Analyser le fichier XML.
				Document document = constructeur.parse(inputFile);
		
				//Obtenez l'élément de title par nom de balise.
				Node titre = document.getElementsByTagName("dc:title").item(0);
				
				//modifier le subject
				titre.setTextContent(settitle);		
				
				//sauvegarder  les modifications dans le fichier XML.
				TransformerFactory changer = TransformerFactory.newInstance();
				Transformer transformer = changer.newTransformer();
				DOMSource source = new DOMSource(document);
				StreamResult result=new StreamResult(new File(fichierXML));
				transformer.transform(source, result);
	      } catch (Exception e) {
		   e.printStackTrace();
	   }
	}
	
	public static void modifySubject(String fichier, String setSubject) {
	     try {
				File inputFile = new File(fichier);
				DocumentBuilderFactory Factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder constructeur = Factory.newDocumentBuilder();
				
				//Analyser le fichier XML.
				Document document = constructeur.parse(inputFile);
		
				//Obtenez l'élément de subject par nom de balise.
				Node sujet = document.getElementsByTagName("dc:subject").item(0);
				
				//modifier le subject
				sujet.setTextContent(setSubject);		
				
				//sauvegarder  les modifications dans le fichier XML.
				TransformerFactory changer = TransformerFactory.newInstance();
				Transformer transformer = changer.newTransformer();
				DOMSource source = new DOMSource(document);
				StreamResult result=new StreamResult(new File(fichier));
				transformer.transform(source, result);
	      } catch (Exception e) {
		   e.printStackTrace();
	   }
	}
}

