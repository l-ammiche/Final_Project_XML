//javac *.java
//java Cli -f "C:\\Users\\louni\\OneDrive\\Bureau\\hellokjdqfb.odt"
import java.io.File;
import java.io.IOException;

/**
 * La classe Cli regroupe tous les main de toutes les classes utilisées.
 *
 */
public class Cli {
	/**
	 * fonction principale
	 */
	public static void main(String[] args) throws Exception,IOException{
		
		//verifie la taille de la liste des arguments (args) si égale à 1 et que le premier element est -h
		if (args.length == 1 && args[0].equals("-h")) {
				System.out.println("--------------------------------------HELP----------------------------------------" + "\n \n" + " -f (+) nom du fichier ODT : Extraire les métadonnées d'un fichier"
							+ "\n" + " -d (+) nom du dossier explorer : Explorer un dossier à la recherche de ficher odt" + "\n Options :"
								+ "\n	--title (+) intitulé du titre: modifier ou d’ajouter la métadonnée de titre au document" + "\n	--subject (+) intitulé du suject: modifier ou d’ajouter la métadonnée de titre au document" + "\n"
									+ "----------------------------------------------------------------------------------"); 

//--------------------------------------------------------------------------------------------------------			

		} else if (args.length==2 ) {
			if (args[0].equals("-f")){//Verifier premier element est -f
				
				// variable local
				String nomodt = args[1];//fichier odt à traiter
				String nomzip = "C:\\Users\\louni\\OneDrive\\Bureau\\aaa\\hhhh.zip";
	
				// Changer extension de odt en zip
		        EditExtension.extension(nomodt, nomzip);
		        
		        // Dezipper et extraire (Unzip)
		        File repertoire = new File("C:\\Users\\louni\\OneDrive\\Bureau\\aaa");
		        Unzip.extract(repertoire, nomzip);
		        
		        //ReadXML
		        String ficherXML = "C:\\Users\\louni\\OneDrive\\Bureau\\aaa\\meta.xml";
		        ReadXML.lire(ficherXML);
		        
			} else if(args[0].equals("-d")){//Verifier premier element est -d
						
					// Trier repertoire (Sort)
					System.out.println("-----------------------------------------Fichier ODT-----------------------------------------" + "\n");
					String chemin = args[1];//dossier à trier
					Sort explorateur = new Sort(chemin, 0);//0 = coefficient d'indentation
					explorateur.filtre();
					System.out.println("---------------------------------------------------------------------------------------------" + "\n");
				
			} else { //sinon afficher message d'erreur
				System.out.println("-------------------------------Erreur-------------------------------" + "\n" + "Désolé, un problème est survenu lors de la saisie des options."
						+ "\n" + "      Si vous voulez en savoir plus merci de saisir l’option « -h »." + "\n" + "--------------------------------------------------------------------");
			}
			//supprimer les fichiers residuels
			File dir = new File("C:\\Users\\louni\\OneDrive\\Bureau\\aaa");
			Delete.delete(dir);

//--------------------------------------------------------------------------------------------------------			

		} else if (args.length==4 && args[0].equals("-f")){
				
				// variable local
				String nomodt = args[1];
				String nomzip = "C:\\Users\\louni\\OneDrive\\Bureau\\aaa\\hhhh.zip";
	
				// Changer extension de odt en zip
		        EditExtension.extension(nomodt, nomzip);
		        
		        // Dezipper et extraire
		        File repertoire = new File("C:\\Users\\louni\\OneDrive\\Bureau\\aaa");
		        Unzip.extract(repertoire, nomzip);

				if (args[2].equals("--title")) {					
					// ModifyXML title
					 String ficherXML = "C:\\Users\\louni\\OneDrive\\Bureau\\aaa\\meta.xml";
					 ModifyXML.modifyTitle(ficherXML, args[3]);
					 ReadXML.lire(ficherXML);

				} else if (args[2].equals("--subject")) {
					// ModifyXML subject
					String ficherXML = "C:\\Users\\louni\\OneDrive\\Bureau\\aaa\\meta.xml";
					ModifyXML.modifySubject(ficherXML, args[3]);
					ReadXML.lire(ficherXML);

				} else{ //sinon afficher message d'erreur
					System.out.println("-------------------------------Erreur-------------------------------" + "\n" + "Désolé, un problème est survenu lors de la saisie des options."
							+ "\n" + "      Si vous voulez en savoir plus merci de saisir l’option « -h »." + "\n" + "--------------------------------------------------------------------");
			
			}		
			
			//supprimer les fichiers residuels
			File dir = new File("C:\\Users\\louni\\OneDrive\\Bureau\\aaa");
			Delete.delete(dir);

//--------------------------------------------------------------------------------------------------------						

		} else{ //sinon si non dans tous les autres cas afficher message d'erreur
				System.out.println("-------------------------------Erreur-------------------------------" + "\n" + "Désolé, un problème est survenu lors de la saisie des options."
						+ "\n" + "      Si vous voulez en savoir plus merci de saisir l’option « -h »." + "\n" + "--------------------------------------------------------------------");
		
		}
		
		
		
	}
}