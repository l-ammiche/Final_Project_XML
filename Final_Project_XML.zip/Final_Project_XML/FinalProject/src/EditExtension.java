import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Classe qui permet de  modifier l'extension d'un fichier.
 *  Elle permet de copier/coller un fichier  et de modifier son extension.
 *
 */
public class EditExtension {
	
	/**
	 * La méthode prend en argument deux chaînes de caractère.
	 * @param nom  chemin d'accès du fichier que l'on souhaite renommer
	 * @param zip  chemin d'accès de l'endroit ou l'on souhaite copier le fichier suivie par quoi on souhaite le renommer
	 */
	public static void extension(String nom, String zip) {

		File f = new File(nom);
		File r = new File(zip);
    InputStream is = null;
    OutputStream os = null;
  
    try {
        is = new FileInputStream(f);
        os = new FileOutputStream(r);
        byte[] buffer = new byte[1024];
        int len;
        while ((len = is.read(buffer)) > 0) {
            os.write(buffer, 0, len);
        }
        is.close();
        os.close();
    }
    catch(IOException e){
        e.printStackTrace();
    }
  }
}

