import java.io.*;
import javax.xml.parsers.*;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

/**
 * La classe permet de lire les éléments d'un fichier XML.
 *
 */
public class ReadXML {
	
	/**
	 * La méthode prend en argument une chaîne de caractère.
	 * @param ficherXML chemin du fichier XML à traiter
	 */
	public static void lire(String ficherXML) {
		
		try {
	    	File inputFile = new File(ficherXML);
	    	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	        Document doc = dBuilder.parse(inputFile);
	        doc.getDocumentElement().normalize();
	        
	        NodeList liste = doc.getElementsByTagName("office:meta");
	        NodeList metalist = liste.item(0).getChildNodes();
	        Node tmp = null;
	        
	        System.out.println("--------------------METADONNEES---------------------");
	        
	        for (int i = 0; i < metalist.getLength(); i++) {
	            tmp = metalist.item(i);
	            
	            if (tmp.getNodeName().equals("dc:title")) {
	                System.out.println("Title : " + tmp.getTextContent() + "\n");
	            }
	            
	            if (tmp.getNodeName().equals("dc:description")) {
	                System.out.println("Description : " + tmp.getTextContent() + "\n");
	            }
	            
	            if (tmp.getNodeName().equals("dc:subject")) {
	                System.out.println("Subject : " + tmp.getTextContent() + "\n");

	            }
	            if (tmp.getNodeName().equals("meta:initial-creator")) {
	                System.out.println("Initial creator : " + tmp.getTextContent() + "\n");
	            }

	            if (tmp.getNodeName().equals("dc:creator")) {
                    System.out.println("Creator :  " + tmp.getTextContent() + "\n");
                }
	            
	            if (tmp.getNodeName().equals("dc:creation-date")) {
                    System.out.println("Creation-date :  " + tmp.getTextContent() + "\n");
                }
	            
                if (tmp.getNodeName().equals("dc:date")) {
                    System.out.println("Date :  " + tmp.getTextContent() + "\n");
                }
                
                if (tmp.getNodeName().equals("meta:document-statistic")) {
                	System.out.println("statistiques diverses: ");
                	for(int y= 0; y<7; y++) {
                        System.out.println("	" +tmp.getAttributes().item(y));
                        }
                }
                
	        }
	        
	        System.out.println("----------------------------------------------------");
	        
	    } catch (Exception e) {
	    	System.out.println(e);
        }
	}
}
