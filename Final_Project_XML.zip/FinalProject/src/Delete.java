import java.io.File;
import java.io.IOException;

/**
 * Classe qui permet de supprimer les fichiers d'un dossier.
 *
 */
public class Delete {
	
	/**
	 * La méthode prend en argument une chaîne de caractère.
	 * @param dossier chemin du dossier à supprimer
	 * @throws IOException Signale qu'une exception d'E/S quelconque s'est produite. Cette classe est la classe générale des exceptions produites par des opérations d'E/S ayant échoué ou interrompues.
	 */
    public static void delete(File dossier) throws IOException{
 
      if(dossier.isDirectory()){
        
        if(dossier.list().length == 0){
        	System.out.println("");
        }
        
        else{
          String files[] = dossier.list();
     
          for (String tmp : files) {
             File file = new File(dossier, tmp);
             delete(file);
          }
        }
      }
      
      else{
          dossier.delete();
      }
    } 
}