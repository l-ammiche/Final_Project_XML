import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * La classe permet d'extraire les fichiers d'un dossier Zip.
 *
 */
public class Unzip {
	/**
	 * La méthode prend en argument deux chaînes de caractère.
	 * @param repertoire lieu où l'on souhaite extraire les fichier d'un dossier Zip
	 * @param chemin dossier Zip
	 * @throws FileNotFoundException Signale qu'une tentative d'ouverture du fichier indiqué par un nom de chemin spécifié a échoué.
	 * @throws IOException Signale qu'une exception d'E/S quelconque s'est produite. Cette classe est la classe générale des exceptions produites par des opérations d'E/S ayant échoué ou interrompues.
	 */
	public static void extract(File repertoire, String chemin) throws FileNotFoundException, IOException {
		ZipInputStream zin = new ZipInputStream(new FileInputStream(chemin));
		ZipEntry entry = null;
		
		while ((entry = zin.getNextEntry())!= null) {
			
			File file = new File(repertoire.getCanonicalPath() + "\\" + entry.getName());
			
			if (entry.isDirectory()) {
				file.mkdir();
				continue;
			}
			
			int len;
			byte[]data = new byte[1024];
			file.getParentFile().mkdirs();
			OutputStream fos = new BufferedOutputStream(new FileOutputStream(file));
			while ((len = zin.read(data)) != -1) {
				fos.write(data, 0, len);
			}
			fos.close();
			zin.closeEntry();
		}
		zin.close();
	}
}
