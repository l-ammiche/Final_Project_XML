import java.io.File;

/**
 * 	Ce programme Java définit une classe 
 *  qui permet de trier un dossier afin d'extraire les fichier odt ou odf qui sont présents.
 */
public class Sort {
	private String chemin;
	private int Indentation;
	
	/**
	 * La classe Sort à un seul constructeur qui prend un objet
	 * String et un entier en entrée.
	 * @param chemin chemin du dossier à trier
	 * @param Indentation taille de l'indentation
	 */
	public Sort(String chemin, int Indentation) {
		this.chemin = chemin;
		this.Indentation = Indentation;
	}
	
	/*
	 * La classe Sort possède une seule méthode appelée filtre() qui
	 * effectue les opérations suivantes :
	 */
	public void filtre() {
		
		/**
		 * création d'un objet File en utilisant l'attribut chemin de l'objet Sort.
		 */
		File file = new File(chemin);
		
		/**
		 * Elle récupère une liste de tous les fichiers et répertoires du répertoire spécifié en utilisant la méthode
		 * listFiles() de la classe File.
		 */
		File[] listeFichiers = file.listFiles();
		if (listeFichiers != null) {
			for (int i = 0; i < listeFichiers.length; i++) {
				if (listeFichiers[i].isDirectory()) {
					String nomDos = listeFichiers[i].getName();
					// Print the name of the directory with the appropriate indentation
					for (int j = 0; j < Indentation; j++) {
						System.out.print(" ");
					}
					System.out.println(" Dossier " + nomDos);
					// Create a new Explorateur1 object with an increased indentation level
					// and recursively call filtre() on the directory
					Sort explorateur1 = new Sort(listeFichiers[i].getPath(), Indentation + 1);
					explorateur1.filtre();
				}
				else if (listeFichiers[i].isFile()) {
					String nomFichier = listeFichiers[i].getName();
					int pt = nomFichier.lastIndexOf(".");
					String ext = nomFichier.substring(pt + 1);
					if (ext.equals("odt") || ext.equals("odf")) {
						// Print the name of the file with the appropriate indentation
						for (int j = 0; j < Indentation; j++) {
							System.out.print("	");
						}
						System.out.println(" Fichier " + nomFichier);
						
						for (int j = 0; j < Indentation; j++) {
							System.out.print("	");
						}
						System.out.println("	Adresse: " + listeFichiers[i].getAbsolutePath());
					}
				}
			}
		}
	}
}